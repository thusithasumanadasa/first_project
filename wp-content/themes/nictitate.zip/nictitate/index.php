<?php
$kopa_setting = kopa_get_template_setting();
get_template_part('layout', $kopa_setting['layout_id']);

