WebFont.load({
    google: {
        families: ['Rokkitt:400','Open+Sans:400','Raleway:400,600,500']
    }
});